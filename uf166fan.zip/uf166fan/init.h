#ifndef _INIT_H_
#define _INIT_H_
#include<sc.h>

void Init_System();
void Init_GPIO();
void Init_Interupt();
#endif 