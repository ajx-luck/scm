char _IT_ID;
char _IT_DATA;
char _IT_INT_MASK;

persistent volatile char __DCByte;
persistent volatile char __DCDelay;

char  _IT_SAVE_BSR;
char  _IT_SAVE_WREG;
char  _IT_SAVE_STATUS;

