#include <errno.h>

int errno;
