/*
 * Function: getche
 * Weak implementation.  User implementation may be required
 */

char 
getche(void)
{
	return 0;
}

