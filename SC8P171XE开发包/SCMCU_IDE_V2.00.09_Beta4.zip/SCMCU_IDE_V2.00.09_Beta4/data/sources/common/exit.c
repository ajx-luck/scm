#include	<stdlib.h>

#ifndef _EXIT_MACRO_
void
exit(int v)
{
	for(;;)
		continue;
}
#endif

