/*******************************************************************************
* Copyright (C) 2019 China Micro Semiconductor Limited Company. All Rights Reserved.
*
* This software is owned and published by:
* CMS LLC, No 2609-10, Taurus Plaza, TaoyuanRoad, NanshanDistrict, Shenzhen, China.
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with CMS
* components. This software is licensed by CMS to be adapted only
* for use in systems utilizing CMS components. CMS shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. CMS is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/

/****************************************************************************/
/** \file demo_spi.c
**
**  
**
**	History:
**	
*****************************************************************************/
/****************************************************************************/
/*	include files
*****************************************************************************/
#include "demo_spi.h"

/****************************************************************************/
/*	Local pre-processor symbols('#define')
****************************************************************************/


/****************************************************************************/
/*	Global variable definitions(declared in header file with 'extern')
****************************************************************************/

/****************************************************************************/
/*	Local type definitions('typedef')
****************************************************************************/

/****************************************************************************/
/*	Local variable  definitions('static')
****************************************************************************/

/****************************************************************************/
/*	Local function prototypes('static')
****************************************************************************/

/*****************************************************************************
 ** \brief	SPI_Transmit
 **			
** \param [in] SendData: ���͵�ֵ
 ** \return  16bit ��ȡ��ֵ
 ** \note	
*****************************************************************************/
uint8_t  SPI_Transmit(uint8_t  Data)
{	
	SPDR = Data;
	while(!SPI_GetTransferIntFlag());
	return (SPDR);				
}
/****************************************************************************/
/*	Function implementation - global ('extern') and local('static')
****************************************************************************/
/******************************************************************************
 ** \brief	 SPI_Config
 ** \param [in] 
 **            	
 ** \return  none
 ** \note  
 ******************************************************************************/
void SPI_Config(void)
{
	/*
	(1)����SPIʱ��
	*/
	SPI_ConfigClk(SPI_CLK_DIV_8);									/*����ʱ��*/
	/*
	(2)����SPI����ģʽ
	*/
	SPI_ConfigRunMode(SPI_CLK_CPOL_LOW, SPI_CLK_CPHA_0, SPI_NSS_SSCR_CONTROL);/*����SPI ����ʱʱ��Ϊ�͵�ƽ����λѡ��CPHA = 0 */
																	/*����SPI NSSx�ź���SSCR�е����ݿ���*/																							
	/*
	(3)����IO�ڸ���
	*/
	GPIO_SET_MUX_MODE(P15CFG,GPIO_MUX_SCLK);		/*SCLK*/
	GPIO_SET_MUX_MODE(P17CFG,GPIO_MUX_MISO);		/*MISO*/
	GPIO_SET_MUX_MODE(P16CFG,GPIO_MUX_MOSI);		/*MOSI*/
	GPIO_SET_MUX_MODE(P36CFG,GPIO_MUX_NSS);		/*CS*/	
	
	/*
	(4)����SPI����or�ӻ�ģʽ
	*/
	SPI_EnableSlaveMode();	
	
		/*
	(5)�����жϷ�ʽ
	*/
	SPI_EnableIntFlag();
	/*
	(6)�����ж����ȼ�
	*/
	IRQ_SET_PRIORITY(IRQ_SPI, IRQ_PRIORITY_LOW);
	/*
	(7)�������ж�
	*/	
	IRQ_ALL_ENABLE();	
	
	/*
	(8)����SPI
	*/
	SPI_Start();
}









