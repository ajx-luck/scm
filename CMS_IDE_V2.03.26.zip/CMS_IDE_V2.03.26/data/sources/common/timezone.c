#include	<time.h>

/*
 *	$Id$
 *
 *	$Log$
 *	Revision 1.2  1998/08/21 02:09:12  clyde
 *	Updates from 8086 code.
 *
 */

int	time_zone;
long	timezone;
